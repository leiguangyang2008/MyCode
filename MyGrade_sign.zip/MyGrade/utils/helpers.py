"""
辅助函数模块 - 包含各种工具函数
"""

def validate_score(score: float, full_score: float) -> bool:
    """验证成绩是否有效"""
    return 0 <= score <= full_score

def validate_name(name: str) -> bool:
    """验证名称是否有效"""
    return bool(name.strip())

def format_percentage(value: float) -> str:
    """格式化百分比"""
    return f"{value:.2f}%"

def sort_exams_by_date(exams: list) -> list:
    """按考试日期排序考试列表"""
    return sorted(exams, key=lambda x: x.get('exam_date', '0000-00-00'))