"""
成绩分析模块 - 负责成绩数据的统计和分析
"""

import numpy as np
from typing import Dict, List, Any, Tuple
from datetime import datetime

class GradeAnalyzer:
    """成绩分析类"""
    
    def __init__(self, data: Dict[str, Any]):
        self.data = data
    
    def calculate_exam_results(self, scores: Dict[str, float]) -> Dict[str, Any]:
        """计算考试成绩结果"""
        total_score = 0
        total_full_score = 0
        score_rates = {}
        
        for subject, score in scores.items():
            full_score = self.data["subjects"][subject]
            score_rate = (score / full_score) * 100
            score_rates[subject] = round(score_rate, 2)
            total_score += score
            total_full_score += full_score
        
        total_score_rate = round((total_score / total_full_score) * 100, 2) if total_full_score > 0 else 0
        
        return {
            "scores": scores,
            "score_rates": score_rates,
            "total_score": total_score,
            "total_full_score": total_full_score,
            "total_score_rate": total_score_rate
        }
    
    def calculate_all_statistics(self) -> Dict[str, Any]:
        """计算所有统计信息"""
        if not self.data["exams"]:
            return {}
        
        # 计算各科目统计
        subject_stats = {}
        for subject in self.data["subjects"]:
            scores = []
            score_rates = []
            
            for exam in self.data["exams"]:
                if subject in exam["scores"]:
                    scores.append(exam["scores"][subject])
                    score_rates.append(exam["score_rates"][subject])
            
            if scores:
                subject_stats[subject] = {
                    "average": np.mean(scores),
                    "max": max(scores),
                    "min": min(scores),
                    "average_rate": np.mean(score_rates),
                    "rate_std": np.std(score_rates) if len(score_rates) > 1 else 0
                }
        
        # 计算总分统计
        total_scores = [exam["total_score"] for exam in self.data["exams"]]
        total_score_rates = [exam["total_score_rate"] for exam in self.data["exams"]]
        
        total_stats = {
            "average": np.mean(total_scores),
            "max": max(total_scores),
            "min": min(total_scores),
            "average_rate": np.mean(total_score_rates),
            "rate_std": np.std(total_score_rates) if len(total_score_rates) > 1 else 0
        }
        
        # 计算趋势数据
        subject_trends = self.calculate_subject_trends()
        total_trends = self.calculate_total_trends()
        
        return {
            "subject_stats": subject_stats,
            "total_stats": total_stats,
            "subject_trends": subject_trends,
            "total_trends": total_trends
        }
    
    def calculate_subject_trends(self) -> Dict[str, List[float]]:
        """计算各科目得分率趋势"""
        trends = {}
        
        for subject in self.data["subjects"]:
            rates = []
            for exam in self.data["exams"]:
                if subject in exam["score_rates"]:
                    rates.append(exam["score_rates"][subject])
            trends[subject] = rates
        
        return trends
    
    def calculate_total_trends(self) -> List[float]:
        """计算总分趋势"""
        return [exam["total_score_rate"] for exam in self.data["exams"]]
    
    def analyze_progress(self) -> Dict[str, Dict[str, Any]]:
        """分析进步/退步情况"""
        if len(self.data["exams"]) < 2:
            return {}
        
        progress = {}
        trends = self.calculate_subject_trends()
        
        for subject, rates in trends.items():
            if len(rates) >= 2:
                first = rates[0]
                latest = rates[-1]
                change = latest - first
                
                # 判断趋势
                if change > 5:  # 提高5%以上视为进步
                    trend = "improving"
                elif change < -5:  # 降低5%以上视为退步
                    trend = "declining"
                else:
                    trend = "stable"
                
                progress[subject] = {
                    "first": first,
                    "latest": latest,
                    "change": change,
                    "trend": trend
                }
        
        return progress
    
    def predict_scores(self, subject: str) -> float:
        """预测下一考试成绩"""
        if subject not in self.data["subjects"] or len(self.data["exams"]) < 2:
            return 0
        
        rates = []
        for exam in self.data["exams"]:
            if subject in exam["score_rates"]:
                rates.append(exam["score_rates"][subject])
        
        if len(rates) < 2:
            return 0
        
        # 简单线性回归预测
        x = np.arange(len(rates))
        y = np.array(rates)
        
        # 计算斜率和截距
        slope, intercept = np.polyfit(x, y, 1)
        
        # 预测下一个点
        predicted_rate = slope * len(rates) + intercept
        
        # 确保预测值在合理范围内
        predicted_rate = max(0, min(100, predicted_rate))
        
        return predicted_rate