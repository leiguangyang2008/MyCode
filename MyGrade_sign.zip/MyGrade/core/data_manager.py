"""
数据管理模块 - 负责数据的加载、保存和验证
"""

import json
import os
from datetime import datetime
from typing import Dict, Any, List
from ..utils.helpers import validate_score, validate_name

class DataManager:
    """数据管理类"""
    
    def __init__(self, data_file: str = "data/student_grades.json"):
        self.data_file = data_file
        self.data = self.load_data()
    
    def ensure_data_dir(self):
        """确保数据目录存在"""
        data_dir = os.path.dirname(self.data_file)
        if data_dir and not os.path.exists(data_dir):
            os.makedirs(data_dir)
    
    def load_data(self) -> Dict[str, Any]:
        """加载数据文件"""
        self.ensure_data_dir()
        
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except (json.JSONDecodeError, FileNotFoundError):
                print("数据文件损坏或无法读取，将创建新文件")
                return self.initialize_data_structure()
        else:
            return self.initialize_data_structure()
    
    def initialize_data_structure(self) -> Dict[str, Any]:
        """初始化数据结构"""
        return {
            "student_info": {
                "name": "",
                "initialized_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            },
            "subjects": {},
            "exams": [],
            "statistics": {
                "last_updated": "",
                "subject_trends": {},
                "total_trends": []
            }
        }
    
    def save_data(self):
        """保存数据到文件"""
        try:
            # 先写入临时文件，再重命名，避免数据损坏
            temp_file = self.data_file + ".tmp"
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(self.data, f, ensure_ascii=False, indent=4)
            
            # 替换原文件
            if os.path.exists(self.data_file):
                os.remove(self.data_file)
            os.rename(temp_file, self.data_file)
            
        except Exception as e:
            print(f"保存数据时发生错误: {e}")
            # 尝试恢复备份
            if os.path.exists(self.data_file + ".backup"):
                print("尝试恢复备份数据...")
                os.rename(self.data_file + ".backup", self.data_file)
    
    def backup_data(self):
        """创建数据备份"""
        if os.path.exists(self.data_file):
            import shutil
            backup_file = f"{self.data_file}.backup.{datetime.now().strftime('%Y%m%d%H%M%S')}"
            shutil.copy2(self.data_file, backup_file)
            print(f"数据已备份到: {backup_file}")
    
    def validate_subject_name(self, name: str) -> bool:
        """验证科目名称是否有效"""
        return bool(name.strip()) and name not in self.data["subjects"]
    
    def validate_exam_name(self, name: str) -> bool:
        """验证考试名称是否有效"""
        if not name.strip():
            return False
        
        # 检查考试是否已存在
        for exam in self.data["exams"]:
            if exam["exam_name"] == name:
                return False
        
        return True
    
    def get_exam_index(self, exam_name: str) -> int:
        """根据考试名称获取索引"""
        for i, exam in enumerate(self.data["exams"]):
            if exam["exam_name"] == exam_name:
                return i
        return -1
    
    def update_statistics(self):
        """更新统计信息"""
        from .analyzer import GradeAnalyzer
        analyzer = GradeAnalyzer(self.data)
        self.data["statistics"] = analyzer.calculate_all_statistics()
        self.data["statistics"]["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")