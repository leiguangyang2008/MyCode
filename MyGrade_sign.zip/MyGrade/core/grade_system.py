"""
成绩系统主类 - 负责用户交互和系统流程控制
"""

from datetime import datetime
from typing import Dict, List, Any
from .data_manager import DataManager
from .analyzer import GradeAnalyzer
from ..visualization.grade_visualizer import GradeVisualizer

class StudentGradeSystem:
    """学生成绩系统主类"""
    
    def __init__(self, data_file: str = "data/student_grades.json"):
        self.data_manager = DataManager(data_file)
        self.data = self.data_manager.data
        self.analyzer = GradeAnalyzer(self.data)
        self.visualizer = GradeVisualizer(self.data)
    
    def initialize_student_info(self):
        """初始化学生信息"""
        print("\n=== 初始化学生信息 ===")
        name = input("请输入学生姓名: ").strip()
        
        if not name:
            print("姓名不能为空!")
            return False
        
        self.data["student_info"]["name"] = name
        print("学生信息初始化完成!")
        self.data_manager.save_data()
        return True
    
    def initialize_subjects(self):
        """初始化科目信息和满分"""
        print("\n=== 初始化科目信息 ===")
        
        if self.data["subjects"]:
            print("当前已有科目:")
            for subject, full_score in self.data["subjects"].items():
                print(f"  {subject}: 满分{full_score}")
            
            choice = input("请选择操作: 1-添加科目, 2-重新设置所有科目, 0-取消: ").strip()
            if choice == '0':
                return True
            elif choice == '2':
                self.data["subjects"] = {}
            elif choice != '1':
                print("无效选择!")
                return False
        
        while True:
            subject = input("请输入科目名称(输入空行结束): ").strip()
            if not subject:
                break
            
            if not self.data_manager.validate_subject_name(subject):
                print(f"科目 '{subject}' 已存在或无效!")
                continue
            
            try:
                full_score = float(input(f"请输入{subject}的满分: ").strip())
                if full_score <= 0:
                    print("满分必须大于0!")
                    continue
                
                self.data["subjects"][subject] = full_score
                print(f"科目 '{subject}' 添加成功!")
            except ValueError:
                print("请输入有效的数字!")
        
        if self.data["subjects"]:
            print("科目设置完成!")
            for subject, full_score in self.data["subjects"].items():
                print(f"  {subject}: 满分{full_score}")
            self.data_manager.save_data()
            return True
        else:
            print("未添加任何科目")
            return False
    
    def add_exam(self):
        """添加考试成绩"""
        if not self.data["subjects"]:
            print("请先初始化科目!")
            return False
        
        print("\n=== 添加考试成绩 ===")
        exam_name = input("请输入考试名称: ").strip()
        
        if not self.data_manager.validate_exam_name(exam_name):
            print(f"考试 '{exam_name}' 已存在或名称无效!")
            return False
        
        scores = {}
        print("请输入各科目成绩:")
        
        for subject, full_score in self.data["subjects"].items():
            while True:
                try:
                    score_input = input(f"{subject}(满分{full_score}): ").strip()
                    if not score_input:
                        print("成绩不能为空!")
                        continue
                    
                    score = float(score_input)
                    if score < 0:
                        print("成绩不能为负数!")
                        continue
                    if score > full_score:
                        print(f"成绩不能超过满分({full_score})!")
                        continue
                    
                    scores[subject] = score
                    break
                except ValueError:
                    print("请输入有效的数字!")
        
        # 计算得分率和总分
        result = self.analyzer.calculate_exam_results(scores)
        
        exam_record = {
            "exam_name": exam_name,
            "scores": scores,
            "score_rates": result["score_rates"],
            "total_score": result["total_score"],
            "total_full_score": result["total_full_score"],
            "total_score_rate": result["total_score_rate"],
            "update_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "exam_date": input("请输入考试日期(YYYY-MM-DD，可选): ").strip() or datetime.now().strftime("%Y-%m-%d")
        }
        
        self.data["exams"].append(exam_record)
        self.data_manager.update_statistics()
        self.data_manager.save_data()
        print(f"考试成绩 '{exam_name}' 添加成功!")
        return True
    
    def modify_exam(self):
        """修改考试成绩"""
        if not self.data["exams"]:
            print("暂无考试成绩记录!")
            return False
        
        print("\n=== 修改考试成绩 ===")
        self.list_exams()
        
        try:
            exam_index = int(input("请选择要修改的考试编号: ").strip()) - 1
            if exam_index < 0 or exam_index >= len(self.data["exams"]):
                print("无效的考试编号!")
                return False
        except ValueError:
            print("请输入有效的数字!")
            return False
        
        exam = self.data["exams"][exam_index]
        print(f"\n正在修改考试: {exam['exam_name']}")
        print("当前成绩:")
        
        for subject, score in exam["scores"].items():
            full_score = self.data["subjects"][subject]
            score_rate = exam["score_rates"][subject]
            print(f"{subject}: {score}/{full_score} (得分率: {score_rate}%)")
        
        print("\n请输入新的成绩(直接回车保持原成绩):")
        new_scores = {}
        
        for subject, full_score in self.data["subjects"].items():
            while True:
                new_score = input(f"{subject}(满分{full_score}, 原成绩: {exam['scores'][subject]}): ").strip()
                if not new_score:  # 直接回车，保持原成绩
                    new_score = exam["scores"][subject]
                    break
                
                try:
                    new_score = float(new_score)
                    if new_score < 0:
                        print("成绩不能为负数!")
                        continue
                    if new_score > full_score:
                        print(f"成绩不能超过满分({full_score})!")
                        continue
                    break
                except ValueError:
                    print("请输入有效的数字!")
                    continue
            
            new_scores[subject] = new_score
        
        # 重新计算得分率和总分
        result = self.analyzer.calculate_exam_results(new_scores)
        
        exam["scores"] = new_scores
        exam["score_rates"] = result["score_rates"]
        exam["total_score"] = result["total_score"]
        exam["total_full_score"] = result["total_full_score"]
        exam["total_score_rate"] = result["total_score_rate"]
        exam["update_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # 更新考试日期
        new_date = input(f"请输入新的考试日期(YYYY-MM-DD，当前: {exam.get('exam_date', '无')}): ").strip()
        if new_date:
            exam["exam_date"] = new_date
        
        self.data_manager.update_statistics()
        self.data_manager.save_data()
        print("考试成绩修改成功!")
        return True
    
    def delete_exam(self):
        """删除考试成绩"""
        if not self.data["exams"]:
            print("暂无考试成绩记录!")
            return False
        
        print("\n=== 删除考试成绩 ===")
        self.list_exams()
        
        try:
            exam_index = int(input("请选择要删除的考试编号: ").strip()) - 1
            if exam_index < 0 or exam_index >= len(self.data["exams"]):
                print("无效的考试编号!")
                return False
        except ValueError:
            print("请输入有效的数字!")
            return False
        
        exam_name = self.data["exams"][exam_index]["exam_name"]
        confirm = input(f"确定要删除考试 '{exam_name}' 吗? (y/N): ").strip().lower()
        
        if confirm == 'y':
            del self.data["exams"][exam_index]
            self.data_manager.update_statistics()
            self.data_manager.save_data()
            print("考试记录删除成功!")
            return True
        else:
            print("取消删除操作")
            return False
    
    def list_exams(self):
        """列出所有考试记录"""
        if not self.data["exams"]:
            print("暂无考试成绩记录!")
            return
        
        print("\n=== 考试记录列表 ===")
        for i, exam in enumerate(self.data["exams"], 1):
            print(f"{i}. {exam['exam_name']} - 总分: {exam['total_score']}/{exam['total_full_score']} " +
                  f"(得分率: {exam['total_score_rate']}%) - 日期: {exam.get('exam_date', '未知')}")
    
    def show_exam_detail(self):
        """显示考试详细信息"""
        if not self.data["exams"]:
            print("暂无考试成绩记录!")
            return
        
        print("\n=== 查看考试详情 ===")
        self.list_exams()
        
        try:
            exam_index = int(input("请选择要查看的考试编号: ").strip()) - 1
            if exam_index < 0 or exam_index >= len(self.data["exams"]):
                print("无效的考试编号!")
                return
        except ValueError:
            print("请输入有效的数字!")
            return
        
        exam = self.data["exams"][exam_index]
        print(f"\n考试名称: {exam['exam_name']}")
        print(f"考试日期: {exam.get('exam_date', '未知')}")
        print(f"更新时间: {exam['update_time']}")
        print("各科目成绩:")
        
        for subject, score in exam["scores"].items():
            full_score = self.data["subjects"][subject]
            score_rate = exam["score_rates"][subject]
            print(f"  {subject}: {score}/{full_score} (得分率: {score_rate}%)")
        
        print(f"总分: {exam['total_score']}/{exam['total_full_score']} (得分率: {exam['total_score_rate']}%)")
    
    def show_statistics(self):
        """显示成绩统计信息"""
        if not self.data["exams"]:
            print("暂无考试成绩记录!")
            return
        
        print("\n=== 成绩统计 ===")
        stats = self.data["statistics"]
        
        print("各科目统计:")
        for subject, subject_stats in stats.get("subject_stats", {}).items():
            full_score = self.data["subjects"][subject]
            print(f"{subject}(满分{full_score}):")
            print(f"  平均分: {subject_stats['average']:.2f}, 最高分: {subject_stats['max']}, 最低分: {subject_stats['min']}")
            print(f"  平均得分率: {subject_stats['average_rate']:.2f}%, 得分率波动: {subject_stats['rate_std']:.2f}")
        
        if stats.get("total_stats"):
            total_stats = stats["total_stats"]
            print(f"\n总分统计:")
            print(f"  平均分: {total_stats['average']:.2f}, 最高分: {total_stats['max']}, 最低分: {total_stats['min']}")
            print(f"  平均得分率: {total_stats['average_rate']:.2f}%, 得分率波动: {total_stats['rate_std']:.2f}")
        
        # 显示进步/退步分析
        progress = self.analyzer.analyze_progress()
        if progress:
            print("\n=== 进步/退步分析 ===")
            for subject, trend in progress.items():
                if trend["trend"] == "improving":
                    print(f"{subject}: 进步中 (最近一次: {trend['latest']}%, 比最初提高: {trend['change']:.2f}%)")
                elif trend["trend"] == "declining":
                    print(f"{subject}: 需注意 (最近一次: {trend['latest']}%, 比最初下降: {abs(trend['change']):.2f}%)")
                else:
                    print(f"{subject}: 保持稳定 (最近一次: {trend['latest']}%)")
    
    def show_visualization(self):
        """显示可视化选项"""
        if not self.data["exams"]:
            print("暂无考试成绩记录，无法生成图表!")
            return
        
        print("\n=== 成绩可视化 ===")
        print("1. 科目成绩趋势图")
        print("2. 总分趋势图")
        print("3. 得分率雷达图")
        print("4. 科目对比柱状图")
        print("5. 返回主菜单")
        
        try:
            choice = input("请选择可视化类型 (1-5): ").strip()
            
            if choice == '1':
                self.visualizer.plot_subject_trends()
            elif choice == '2':
                self.visualizer.plot_total_score_trend()
            elif choice == '3':
                self.visualizer.plot_score_radar()
            elif choice == '4':
                self.visualizer.plot_subject_comparison()
            elif choice == '5':
                return
            else:
                print("无效选择!")
        except Exception as e:
            print(f"生成图表时发生错误: {e}")
            print("请确保已安装matplotlib库: pip install matplotlib")
    
    def run(self):
        """运行系统主循环"""
        # 检查是否需要初始化
        if not self.data["student_info"]["name"]:
            print("欢迎使用学生个人成绩统计系统!")
            if not self.initialize_student_info():
                return
        
        if not self.data["subjects"]:
            if not self.initialize_subjects():
                return
        
        while True:
            print("\n" + "="*50)
            print("学生个人成绩统计与可视化系统")
            print(f"学生: {self.data['student_info']['name']}")
            print("="*50)
            print("1. 初始化学生信息")
            print("2. 初始化/修改科目")
            print("3. 添加考试成绩")
            print("4. 修改考试成绩")
            print("5. 删除考试成绩")
            print("6. 查看考试列表")
            print("7. 查看考试详情")
            print("8. 成绩统计")
            print("9. 成绩可视化")
            print("10. 数据备份")
            print("11. 退出系统")
            print("="*50)
            
            choice = input("请选择操作 (1-11): ").strip()
            
            if choice == '1':
                self.initialize_student_info()
            elif choice == '2':
                self.initialize_subjects()
            elif choice == '3':
                self.add_exam()
            elif choice == '4':
                self.modify_exam()
            elif choice == '5':
                self.delete_exam()
            elif choice == '6':
                self.list_exams()
            elif choice == '7':
                self.show_exam_detail()
            elif choice == '8':
                self.show_statistics()
            elif choice == '9':
                self.show_visualization()
            elif choice == '10':
                self.data_manager.backup_data()
            elif choice == '11':
                print("感谢使用学生个人成绩统计系统，再见!")
                break
            else:
                print("无效的选择，请重新输入!")