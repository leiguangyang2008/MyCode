#!/usr/bin/env python3
"""
学生个人成绩统计与可视化系统 - 主程序入口
"""

import os
import sys

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from core.grade_system import StudentGradeSystem

def main():
    """主函数"""
    system = StudentGradeSystem()
    system.run()

if __name__ == "__main__":
    main()