"""
成绩可视化模块 - 负责生成各种成绩图表
"""

import matplotlib.pyplot as plt
import numpy as np
from typing import Dict, List, Any
from datetime import datetime
from .charts import create_line_chart, create_radar_chart, create_bar_chart

class GradeVisualizer:
    """成绩可视化类"""
    
    def __init__(self, data: Dict[str, Any]):
        self.data = data
        self.setup_style()
    
    def setup_style(self):
        """设置图表样式"""
        plt.style.use('seaborn-v0_8')
        plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False
    
    def plot_subject_trends(self):
        """绘制各科目成绩趋势图"""
        if not self.data["exams"]:
            print("没有考试数据可展示!")
            return
        
        exams = [exam["exam_name"] for exam in self.data["exams"]]
        
        # 为每个科目创建图表
        for subject in self.data["subjects"]:
            scores = []
            for exam in self.data["exams"]:
                if subject in exam["scores"]:
                    scores.append(exam["scores"][subject])
            
            if scores:
                plt.figure(figsize=(10, 6))
                create_line_chart(
                    x_data=exams,
                    y_data=scores,
                    title=f"{subject}成绩趋势",
                    x_label="考试",
                    y_label="分数",
                    color='blue'
                )
                plt.tight_layout()
                plt.show()
    
    def plot_total_score_trend(self):
        """绘制总分趋势图"""
        if len(self.data["exams"]) < 2:
            print("至少需要两次考试数据才能显示趋势!")
            return
        
        exams = [exam["exam_name"] for exam in self.data["exams"]]
        total_scores = [exam["total_score"] for exam in self.data["exams"]]
        total_rates = [exam["total_score_rate"] for exam in self.data["exams"]]
        
        # 创建双Y轴图表
        fig, ax1 = plt.subplots(figsize=(12, 6))
        
        # 绘制总分
        color = 'tab:blue'
        ax1.set_xlabel('考试')
        ax1.set_ylabel('总分', color=color)
        ax1.plot(exams, total_scores, 'o-', color=color, linewidth=2, markersize=8)
        ax1.tick_params(axis='y', labelcolor=color)
        
        # 创建第二个Y轴显示得分率
        ax2 = ax1.twinx()
        color = 'tab:red'
        ax2.set_ylabel('得分率 (%)', color=color)
        ax2.plot(exams, total_rates, 's--', color=color, linewidth=2, markersize=6)
        ax2.tick_params(axis='y', labelcolor=color)
        
        plt.title('总分与得分率趋势')
        fig.tight_layout()
        plt.show()
    
    def plot_score_radar(self):
        """绘制得分率雷达图"""
        if not self.data["exams"]:
            print("没有考试数据可展示!")
            return
        
        # 获取最近一次考试
        latest_exam = self.data["exams"][-1]
        subjects = list(self.data["subjects"].keys())
        score_rates = [latest_exam["score_rates"].get(subject, 0) for subject in subjects]
        
        # 计算平均得分率
        avg_rates = []
        for subject in subjects:
            rates = []
            for exam in self.data["exams"]:
                if subject in exam["score_rates"]:
                    rates.append(exam["score_rates"][subject])
            avg_rates.append(np.mean(rates) if rates else 0)
        
        # 创建雷达图
        create_radar_chart(
            categories=subjects,
            values=score_rates,
            compare_values=avg_rates,
            title="科目得分率雷达图",
            labels=["本次考试", "平均得分率"]
        )
    
    def plot_subject_comparison(self):
        """绘制科目对比柱状图"""
        if not self.data["exams"]:
            print("没有考试数据可展示!")
            return
        
        # 获取最近两次考试
        if len(self.data["exams"]) >= 2:
            exams = self.data["exams"][-2:]
            exam_names = [exam["exam_name"] for exam in exams]
        else:
            exams = [self.data["exams"][-1]]
            exam_names = [exams[0]["exam_name"]]
        
        subjects = list(self.data["subjects"].keys())
        
        # 准备数据
        data = {}
        for subject in subjects:
            data[subject] = []
            for exam in exams:
                if subject in exam["score_rates"]:
                    data[subject].append(exam["score_rates"][subject])
                else:
                    data[subject].append(0)
        
        # 创建柱状图
        create_bar_chart(
            data=data,
            categories=exam_names,
            title="科目得分率对比",
            ylabel="得分率 (%)"
        )
    
    def plot_progress_analysis(self):
        """绘制进步分析图"""
        from ..core.analyzer import GradeAnalyzer
        analyzer = GradeAnalyzer(self.data)
        progress = analyzer.analyze_progress()
        
        if not progress:
            print("没有足够的数据进行进步分析!")
            return
        
        subjects = list(progress.keys())
        changes = [progress[subject]["change"] for subject in subjects]
        
        # 创建颜色映射
        colors = ['green' if change > 0 else 'red' for change in changes]
        
        plt.figure(figsize=(12, 6))
        bars = plt.bar(subjects, changes, color=colors, alpha=0.7)
        
        # 添加数值标签
        for i, bar in enumerate(bars):
            height = bar.get_height()
            plt.text(bar.get_x() + bar.get_width()/2., height + (0.01 if height >= 0 else -0.03),
                    f'{changes[i]:.1f}%', ha='center', va='bottom' if height >= 0 else 'top')
        
        plt.axhline(y=0, color='black', linestyle='-', alpha=0.3)
        plt.title('科目进步/退步分析 (与最初考试相比)')
        plt.ylabel('变化率 (%)')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.show()