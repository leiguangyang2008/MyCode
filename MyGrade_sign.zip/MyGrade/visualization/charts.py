"""
图表生成函数 - 包含各种图表的生成逻辑
"""

import matplotlib.pyplot as plt
import numpy as np
from typing import List, Dict, Any

def create_line_chart(x_data: List[str], y_data: List[float], title: str, 
                     x_label: str, y_label: str, color: str = 'blue'):
    """创建折线图"""
    plt.plot(x_data, y_data, 'o-', color=color, linewidth=2, markersize=8)
    plt.title(title, fontsize=14, fontweight='bold')
    plt.xlabel(x_label)
    plt.ylabel(y_label)
    plt.grid(True, alpha=0.3)
    
    # 添加数值标签
    for i, v in enumerate(y_data):
        plt.annotate(f'{v}', (x_data[i], v), textcoords="offset points", 
                    xytext=(0,10), ha='center')

def create_radar_chart(categories: List[str], values: List[float], 
                      compare_values: List[float] = None, title: str = "雷达图",
                      labels: List[str] = None):
    """创建雷达图"""
    N = len(categories)
    
    # 计算角度
    angles = [n / float(N) * 2 * np.pi for n in range(N)]
    angles += angles[:1]  # 闭合雷达图
    
    # 闭合数据
    values += values[:1]
    if compare_values:
        compare_values += compare_values[:1]
    
    # 初始化雷达图
    fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(polar=True))
    
    # 绘制数据
    ax.plot(angles, values, 'o-', linewidth=2, label=labels[0] if labels else "当前")
    ax.fill(angles, values, alpha=0.25)
    
    if compare_values and labels and len(labels) > 1:
        ax.plot(angles, compare_values, 'o-', linewidth=2, label=labels[1])
        ax.fill(angles, compare_values, alpha=0.25)
    
    # 设置类别标签
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories)
    
    # 设置Y轴标签位置
    ax.set_rlabel_position(30)
    
    # 添加图例
    if labels:
        plt.legend(loc='upper right', bbox_to_anchor=(0.1, 0.1))
    
    plt.title(title, size=16, fontweight='bold')
    plt.tight_layout()
    plt.show()

def create_bar_chart(data: Dict[str, List[float]], categories: List[str], 
                    title: str, ylabel: str):
    """创建分组柱状图"""
    subjects = list(data.keys())
    x = np.arange(len(categories))
    width = 0.8 / len(subjects)
    
    fig, ax = plt.subplots(figsize=(12, 6))
    
    for i, subject in enumerate(subjects):
        offset = width * i - width * (len(subjects) - 1) / 2
        bars = ax.bar(x + offset, data[subject], width, label=subject, alpha=0.8)
        
        # 添加数值标签
        for bar in bars:
            height = bar.get_height()
            ax.annotate(f'{height:.1f}%',
                       xy=(bar.get_x() + bar.get_width() / 2, height),
                       xytext=(0, 3),
                       textcoords="offset points",
                       ha='center', va='bottom')
    
    ax.set_xlabel('考试')
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.set_xticks(x)
    ax.set_xticklabels(categories)
    ax.legend()
    ax.grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    plt.show()